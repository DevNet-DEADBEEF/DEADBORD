# LMP: List Management Protocol

Application Layer (Layer 7) Protocol

Defines basic management commands and responses for the ToDo list app. 

- Response
    - `DONE`
        - Success
        - Action-specific payload
    - `REJECT`
        - Not authorized
        - No payload
    - `NOPE`
        - Failed to complete; error message in the TLON payload (one value).
        - `message1F`
    - `CONFLICT`
        - Data mismatch, TLON payload states expected vs current version
        - `expected1Fcurrent1F`
- Task
    - Actions
        - `CREATE`
            - `name1F`
                - Other fields are created empty/default values
        - `UPDATE`
            - `property1Evalue1F`
                - This can be repeated to update multiple properties at the same time so long as it fits within 1 LMP packet.
                - Comments can be accessed as `comments1Eindex1Evalue1F` where index is the location of the comment in the list
        - `DELETE`
            - No additional payload
        - `OBTAIN`
            - `property1F`
                - This can be repeated to retrieve multiple properties at the same time, as long as the request and response fit within 1 LMP packet. If the response does not fit within a single packet, `NOPE` will be sent.
                - Comments can be accessed as `comments1Eindex1F` where index is the location of the comment in the list
- Lists
    - Actions
        - `CREATE`
        - `UPDATE`
        - `DELETE`
        - `OBTAIN`
- Boards
    - Actions
        - `CREATE`
        - `UPDATE`
        - `DELETE`
        - `OBTAIN`
        - `UPDATE_PERM`
            - `userid1Epermission1F`
                - This can be repeated to update multiple permissions at the same time, as long as the request fits within 1 LMP packet.

Structure:

- Action: 8 bits (lower 2 reserved)
    - 1: Type
        - `0`: Action
        - `1`: Response
    - 2-3: Scope
        - `00`: Board
        - `01`: List
        - `10`: Task
        - `11`: Unused
    - 4-6: Action
        - `000`: `CREATE` or `DONE`
        - `001`: `UPDATE` or `REJECT`
        - `010`: `DELETE` or `NOPE`
        - `011`: `OBTAIN` or `CONFLICT`
        - `100`: `UPDATE_PERM`
- Scope ID (Database ID): 64 bits (0 for `CREATE` as it will not have an existing ID)
- Action ID: 128 bits
    - A UUID that identifies this action. Any packets with a duplicate Action ID receive the same response as the original packet; however, no action is repeated.
- Version: 32 bits
    - Version the sender expects to be modifying; if the current version does not match a `CONFLICT` response will be sent.
    - Only present in `UPDATE`, `DELETE`, and `UPDATE_SECURITY` packets. Version is included in responses with the new current version.
- Payload: Max 4000 bits (500 bytes)