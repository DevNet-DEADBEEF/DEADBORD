# Connection Cycle

6 Way Handshake 

We’re gonna shake hands a lot. 

Connection: 

- Client `HI` [`0000`] → Server
    - Initial Communication
- Server `HI` [`0000`] → Client
    - Confirms receipt of HI, sends initial connection info
- Client `KEY` [`0011`] → Server
    - Sends a key for symmetric encryption to the server
    - Message encrypted with server public key
- Server `ENCRYPT` [`0100`] → Client
    - Symmetric encryption received, ready for data
- Client `INIT` [`0101`] → Server
    - Sends data for defining this connection’s usage
- If the session key lacks permissions or is invalid:
    - Server `REJECT` [`0010`] → Client
        - Server rejection, connection terminated
- Server `GIMME` [`0110`] → Client
    - Ready to receive
- Repeats until all client requests for this connection are complete. Client requests do not wait for a server response before sending again. After the timeout determined in `INIT`, the server will send a `HUH` if expected packets are missing. This is our best-effort retransmission, after which packets are considered lost.
    - Client `GIMME` [`0110`] → Server
        - Client action
    - Server `TAKE` [`0111`] → Client
        - Server response
- Client `BYE` [`0001`] → Server

If a connection reaches expiration:

- Server `BUGOFF` [`1001`] → Client

The connection is immediately terminated, and the connection ID is invalidated.