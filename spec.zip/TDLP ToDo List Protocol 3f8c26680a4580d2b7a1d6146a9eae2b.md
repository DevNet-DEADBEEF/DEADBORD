# TDLP: ToDo List Protocol

[Connection Cycle](Connection%20Cycle%203f8c26680a45805eb6acdc0baffb92a4.md)

[Data Transfer](Data%20Transfer%203f8c26680a4580019ce6e73085d71b95.md)

[TLON](TLON%203f8c26680a4580df8807f80b26a27c53.md)

[LMP: List Management Protocol ](LMP%20List%20Management%20Protocol%203ffc26680a45809dbeacda1367397cf3.md)

Transport Layer (Layer 4) Protocol

Manages connection creation and security with the TODO list server. TDLP creates a secure connection, transmits a predefined number of action packets, and sends responses. Action packets cannot be segmented and must fit within the defined size in LMP. It is up to the sender and receiver to decide how to use TLON to make actions fit within this limit, such as only fetching one field of a task per action.

Wrapped in UDP for port handling. TDLP does not examine the UDP header at all; UDP exists separately.

When encrypted, it encrypts the entire TDLP packet, excluding the Connection ID and Packet ID. The server’s public key is hardcoded for deployment. TDLP uses AES-256-CTR for encryption without integrity verification. Each connection uses a fresh 256-bit key and separate random 64-bit nonce prefixes for each direction. The 128-bit AES counter block consists of the 64-bit nonce prefix, a 16-bit packet counter, a 16-bit reserved field (zero), and a 32-bit block counter. Packet counters increment for each newly encrypted packet, including control messages, independently of TDLP packet IDs. Retransmissions reuse the original ciphertext. Connections must terminate or rekey before the 16-bit counter wraps, and counter values must never be reused with different plaintext under the same key.

Connection IDs are created by the server (sent to the client in the initial `HI`) by randomly generating a valid ID. Once a connection is closed, either via `REJECT`, `BYE`, or `BUGOFF`, the connection ID cannot be used again until it is re-established by the server (with a `HI` with a connection ID of 0) and uses a new encryption key. Connection IDs are not used for any security, as LMP handles that with session keys.

Packet IDs track the packet number for each action packet. Connection initialization and closing packets have a packet ID of 0. For packets with an ID of 0, duplicate is defined as a duplicate header, as these are only used in a specific order. If a duplicate packet is received, the same response is transmitted again. For each TDLP connection, client action packet IDs begin at 1 and increment by 1 for each unique action packet. `INIT.PacketCount` defines the expected ID range `[1, PacketCount]`. 

Retransmissions use the same exact packet data (including packet IDs, etc.) as the original packet.

Timeouts:

- Connection Expiration
    - At this time, the connection will be terminated by the server with a single `BUGOFF` message to the client. If the client attempts to use the Connection ID again without the server initializing that connection ID again, it will be rejected with `BUGOFF`. If a packet arrives after the `BUGOFF` message, it will still be rejected with `BUGOFF`. This will be rate limited to a maximum of 1/sec/Connection ID, excess packets will be dropped entirely.
- Payload Timeout
    - Payload timeout is defined by the client in `INIT`. If the server doesn’t receive all packets by this timeout, it will send `HUH` with the missing packet IDs.
- Response Timeout
    - Used to indicate a deadline for a response to this packet. If a response is not received by this timestamp, the packet will be re-transmitted. Uses the ToDo List epoch from the DB, and is only held internally by the sender.

Structure: 

- Connection ID: 32 bits (0 for initial connection)
- Packet ID: 16 bits
- Message Header: 8 bits (lower 4 reserved 0)
    - `0000`: `HI` <UNENCRYPTED>
        - Initial connection and receipt response
    - `0001`: `BYE`
        - Disconnection, after sending the sender immediately considers the connection closed. The receiver drops the connection after receiving a `BYE` packet.
    - `0010`: `REJECT`
        - Server: rejection
    - `0011`: `KEY`
        - Client: Encrypted TLON containing a symmetric encryption key
    - `0100`: `ENCRYPT`
        - Server: encryption is now active
    - `0101`: `INIT`
        - Client: Connection setup information
    - `0110`: `GIMME`
        - Client: LMP action packet
        - Server: Connection ready packet
    - `0111`: `TAKE`
        - Server: LMP response
    - `1000`: `HUH`
        - Server: Packet receive timeout, request retransmit
    - `1001`: `BUGOFF`
        - Server: Connection expiration reached
- Message-Specific payloads: (Other messages have no payload)
    - `HI`
        - Server
            - Contains TLON with generated connection ID and connection expiration (using the TODO epoch)
                - `connectionid1Fconnectionexp1F`
    - `KEY`
        - TLON with four values, being:
            - `algorithm1Fkey1Fclientprefix1Fserverprefix1F` (e.g. `aes2561F60a0ef12dfdc44f2efff24fd7c85710c4175929bd5a324c5ec85d519073d2f081F00000000000000000000000000000000000000000000000000000000000000001F00000000000000000000000000000000000000000000000000000000000000001F`
        - Encryption algorithms are pre-defined and the option remains only for potential expansion.
    - `INIT`
        - TLON Table contains:
            - User Session Key
            - Resource Ids
                - Prefixed with 2 bits for scope
                    - 00: Board
                    - 01: List
                    - 10: Task
                    - 11: Unused
            - Packet Count (number of packets that will be sent)
                - Packet count of 0 is invalid
            - Timeout (How long the server should wait to receive all packets before `HUH`ing)
            - `sessionkey1Fresourceid1Eresourceid1Eresourceid1Fpacketcount1Ftimeout1F`
        - This data is attached to the connection information in the server, and LMP will validate against the session key for authorization.
    - `GIMME`
        - Client
            - Contains an LMP packet
    - `TAKE`
        - Contains an LMP response
    - `HUH`
        - Contains TLON with a list of packet IDs that are missing
            - `packetid1Epacketid1Epacketid1F`